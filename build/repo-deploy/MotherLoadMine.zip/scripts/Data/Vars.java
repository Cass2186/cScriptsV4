package scripts.Data;

public class Vars {




}
