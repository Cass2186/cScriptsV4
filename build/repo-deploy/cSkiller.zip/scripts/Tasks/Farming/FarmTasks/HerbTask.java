package scripts.Tasks.Farming.FarmTasks;

import scripts.API.Priority;
import scripts.API.Task;

public class HerbTask implements Task {



    @Override
    public Priority priority() {
        return null;
    }

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public void execute() {

    }

    @Override
    public String taskName() {
        return null;
    }
}
