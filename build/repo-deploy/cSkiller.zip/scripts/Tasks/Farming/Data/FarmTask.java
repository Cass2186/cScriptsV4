package scripts.Tasks.Farming.Data;

public interface FarmTask {

     int getTeleItem();
     int getSeedId();

}
