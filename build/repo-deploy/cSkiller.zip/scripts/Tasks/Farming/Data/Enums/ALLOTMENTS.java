package scripts.Tasks.Farming.Data.Enums;

import org.tribot.api.General;
import org.tribot.api2007.Skills;
import scripts.Tasks.Farming.Data.FarmConst;
import scripts.Tasks.Farming.Data.FarmVars;

public class ALLOTMENTS {


    public static void determineAllotmentId() {
        if (Skills.getCurrentLevel(Skills.SKILLS.FARMING) < 5) {
            FarmVars.get().currentAllotmentId = FarmConst.POTATO_SEEDS;

        } else if (Skills.getCurrentLevel(Skills.SKILLS.FARMING) < 7) {
            FarmVars.get().currentAllotmentId = FarmConst.ONION_SEEDS;

        } else if (Skills.getCurrentLevel(Skills.SKILLS.FARMING) < 12) {
            FarmVars.get().currentAllotmentId = FarmConst.CABBAGE_SEEDS;

        } else if (Skills.getCurrentLevel(Skills.SKILLS.FARMING) < 20) {
            FarmVars.get().currentAllotmentId = FarmConst.TOMATO_SEEDS;

        } else if (Skills.getCurrentLevel(Skills.SKILLS.FARMING) < 31) {
            FarmVars.get().currentAllotmentId = FarmConst.SWEETCORN_SEEDS;

        } else if (Skills.getCurrentLevel(Skills.SKILLS.FARMING) < 47) {
            FarmVars.get().currentAllotmentId = FarmConst.STRAWBERRY_SEEDS;

        } else if (Skills.getCurrentLevel(Skills.SKILLS.FARMING) < 61) {
            FarmVars.get().currentAllotmentId = FarmConst.WATERMELON_SEEDS;

        } else if (Skills.getCurrentLevel(Skills.SKILLS.FARMING) >= 61) {
            FarmVars.get().currentAllotmentId = FarmConst.SNAPEGRASS_SEEDS;
        }
        General.println("[Debug]: Current allotment seed is: " + FarmVars.get().currentAllotmentId);
    }

}
