package scripts;

import org.tribot.script.sdk.painting.MouseSplinePaint;

import java.awt.*;
import java.util.List;

public class cOrbCharger  {




}
