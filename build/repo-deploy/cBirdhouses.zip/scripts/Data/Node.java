package scripts.Data;


public abstract class Node {

    public abstract void execute();

    public abstract boolean validate();

}
