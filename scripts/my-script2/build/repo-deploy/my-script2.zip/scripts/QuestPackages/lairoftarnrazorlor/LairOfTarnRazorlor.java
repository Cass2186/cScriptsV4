package scripts.QuestPackages.lairoftarnrazorlor;

public class LairOfTarnRazorlor {
}
