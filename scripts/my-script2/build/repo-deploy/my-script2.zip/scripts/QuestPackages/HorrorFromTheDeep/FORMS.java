package scripts.QuestPackages.HorrorFromTheDeep;

public enum FORMS {


    WHITE_FORM(983),
    BLUE_FORM(984),
    BROWN_FORM(986),
    RED_FORM(985),
    ORANGE_FORM(988),
    GREEN_FORM(987);

    FORMS(int id) {
        this.id = id;
    }

    public int id;

}
