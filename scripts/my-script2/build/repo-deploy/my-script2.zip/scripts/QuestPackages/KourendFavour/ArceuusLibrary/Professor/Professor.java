package scripts.QuestPackages.KourendFavour.ArceuusLibrary.Professor;

import org.tribot.api2007.types.RSTile;

public interface Professor {

    String getName();

    RSTile getPosition();

}