package scripts.MoneyMaking.ClockWorks;

public class ClockWorkVars {

    public static boolean useButler = false;
}
