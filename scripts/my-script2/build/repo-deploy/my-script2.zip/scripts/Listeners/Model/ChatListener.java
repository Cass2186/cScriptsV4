package scripts.Listeners.Model;

import org.tribot.api2007.types.RSInterfaceChild;

public interface ChatListener {

    void onAppear();

}
