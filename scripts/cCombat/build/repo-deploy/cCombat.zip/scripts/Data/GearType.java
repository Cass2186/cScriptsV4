package scripts.Data;

public enum GearType {

    MELEE,
    MAGIC_MELEE,
    RANGED,
    MAGIC
}
