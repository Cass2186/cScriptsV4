package scripts.Paint;

public class Status {

    public static String formatStatus(String s){

        return s;
    }
}
