package scripts;

import java.awt.event.KeyEvent;

public class Keyboard extends org.tribot.api.input.Keyboard {

    public static int SPACE_KEY_CODE = 32;
    public static final char VK_1 = KeyEvent.VK_1;
    public static final char VK_2 = KeyEvent.VK_2;
    public static final char VK_3 = KeyEvent.VK_3;
    public static final char VK_4 = KeyEvent.VK_4;
    public static char SPACE_KEY_CHAR = KeyEvent.VK_SPACE;

    public static final char SPACEBAR = KeyEvent.VK_SPACE;



}
