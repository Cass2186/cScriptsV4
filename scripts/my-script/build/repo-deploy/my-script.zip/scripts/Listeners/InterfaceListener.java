package scripts.Listeners;

import org.tribot.api2007.types.RSInterfaceChild;

public interface InterfaceListener {

    void onAppear(RSInterfaceChild rsInterfaceChild);

}