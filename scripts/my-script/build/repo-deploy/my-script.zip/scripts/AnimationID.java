package scripts;

public class AnimationID {
    public static final int ZULRAH_DEATH = 5804;
    public static final int ZULRAH_PHASE = 5072;
}
