package scripts.Data;

public enum CrabType {
    SAND_CRABS,
    AMMONITE_CRABS,
    ROCK_CRABS
}
