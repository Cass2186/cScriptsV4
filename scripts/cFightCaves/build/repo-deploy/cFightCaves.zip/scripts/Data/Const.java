package scripts.Data;

public class Const {

    public static int CAVE_ENTRANCE_ID = 11834;
}
