package scripts.Data;

public class SpawnPredictor {
    void getSpawn(){

        Integer[] spawns = {3, 5, 2, 1, 5, 3, 4, 1, 2, 3, 5, 4, 1, 2, 4};

    }
}
