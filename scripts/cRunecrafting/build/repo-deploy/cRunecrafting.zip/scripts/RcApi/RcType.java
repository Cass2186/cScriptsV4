package scripts.RcApi;

public enum RcType {
    ABYSS,
    REGULAR,
    ZMI,
    OTHER;
    
}
