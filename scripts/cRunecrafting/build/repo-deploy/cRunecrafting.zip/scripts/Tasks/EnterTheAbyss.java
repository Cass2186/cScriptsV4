package scripts.Tasks;

public class EnterTheAbyss {
}
