package scripts.Tasks.Guardians;

public class WaitForGame {

    int gameVarbit = 13688; // 0 = when started, 1 otehrwise
}
