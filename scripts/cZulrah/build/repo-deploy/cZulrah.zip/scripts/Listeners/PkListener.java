package scripts.Listeners;

public interface PkListener {

    void onPkerNearby();
}
