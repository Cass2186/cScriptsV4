package scripts.Data.Overlay;

public class ZulrahCurrentPhaseOverlay {


/*
    @Override
    public Dimension render(Graphics2D graphics)
    {
        ZulrahInstance instance = plugin.getInstance();

        if (instance == null)
        {
            return null;
        }

        ZulrahPhase currentPhase = instance.getPhase();
        if (currentPhase == null)
        {
            return null;
        }

        String pattern = instance.getPattern() != null ? instance.getPattern().toString() : "Unknown";
        String title = currentPhase.isJad() ? "JAD PHASE" : pattern;
        Color backgroundColor = currentPhase.getColor();
        BufferedImage zulrahImage = ZulrahImageManager.getZulrahBufferedImage(currentPhase.getType());
        ImagePanelComponent imagePanelComponent = new ImagePanelComponent();
        imagePanelComponent.setTitle(title);
        imagePanelComponent.setBackgroundColor(backgroundColor);
        imagePanelComponent.setImage(zulrahImage);
        return imagePanelComponent.render(graphics);
    }*/
}
