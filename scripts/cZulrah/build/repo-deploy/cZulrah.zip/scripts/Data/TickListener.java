package scripts.Data;

public interface TickListener {
    void onTick();
}
