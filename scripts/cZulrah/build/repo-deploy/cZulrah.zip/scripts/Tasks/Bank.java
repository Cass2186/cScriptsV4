package scripts.Tasks;

public class Bank {
    @Override
    public String toString() {
        return "Banking for Zulrah";
    }

}
