package scripts.Tasks;

public class StartFight {

    @Override
    public String toString() {
        return "Starting Fight";
    }

}
