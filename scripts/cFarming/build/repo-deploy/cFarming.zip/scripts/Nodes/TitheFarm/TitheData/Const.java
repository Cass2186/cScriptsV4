package scripts.Nodes.TitheFarm.TitheData;

public class Const {
    public static int TITHE_PATCH = 27383;
    public static int WATER_BARREL = 5598;
    public static int HARVESTABLE_GOLOVANOVA_PLANT = 27393;
}
