package scripts.dax.tracker.data;

import com.allatori.annotations.DoNotRename;
import lombok.Getter;

@Getter
public class TrackerLocalConfig {
    @DoNotRename
    private String userID;
}
