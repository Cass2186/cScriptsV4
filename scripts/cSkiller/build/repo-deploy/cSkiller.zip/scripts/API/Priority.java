package scripts.API;

/**
 * Credit to @Encoded for the Framework
 */
public enum Priority {
    AFK_HIGHEST,
    HIGHEST,
    HIGH,
    MEDIUM,
    LOW,
    LOWEST,
    NONE

}