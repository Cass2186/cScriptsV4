package scripts.API;

public interface Teleportable {

    public int[] getTeleItem();
}
