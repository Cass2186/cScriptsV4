package scripts.Data.Enums;

public class Methods {
    public enum MAGIC {
        ENCHANT,
        ALCH,
        TELEPORT,
        TELE_ALCH,
        STUN_ALCH,
        BURSTING
    }

    public enum HERBLORE {
        TAR,
        POTIONS
    }

    public enum COOKING {
        FISH,
        WINES
    }

    public enum CRAFTING {
        GOLD_JEWELERY,
        GLASS,
        GEMS,
        LEATHER
    }

    public enum FISHING {

    }

    public enum FLETCHING {

    }

    public enum HUNTER {
        NET_TRAPS,
        FALCONRY,
        BOX_TRAPS
    }

    public enum MINING {
        ORE,
        MLM
    }

    public enum PRAYER {
        POH,
        WILDY
    }

    public enum RUNECRAFTING {

    }

    public enum SLAYER {

    }

    public enum SMITHING {

    }

    public enum THIEVING {

    }

    public enum WOODCUTTING {
        DROP,
        BURN,
        FLETCH
    }


}
