package scripts.Data.Enums.Crafting;

public enum CraftMethods {
    GLASS,
    GEMS,
    BATTLESTAVES,
    LEATHER
}
