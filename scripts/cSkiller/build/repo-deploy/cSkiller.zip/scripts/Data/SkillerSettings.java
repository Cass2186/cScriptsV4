package scripts.Data;

import lombok.Data;

@Data
public class SkillerSettings {

    private Vars vars;
    private String test;

}
