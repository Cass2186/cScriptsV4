package scripts.Data;

import lombok.Data;

@Data
public class SkillerSettings {

    /**
     * This is to be used to save settings in the GUI at a later date
     */

    private Vars vars;
    private String test;

}
