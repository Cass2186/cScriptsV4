package scripts.Tasks.KourendFavour.ArceuusLibrary.Walking;

public enum RoomLinkType {
    WALK,
    UP,
    DOWN
}