package scripts.Tasks.MiscTasks;

public class SwitchSpellBook {
}
