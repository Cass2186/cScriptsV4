package scripts.Tasks.Construction.MahoganyHomes;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class RequiredMaterials {
    public int MinPlanks;
    public int MaxPlanks;
    public int MinSteelBars;
    public int MaxSteelBars;
}