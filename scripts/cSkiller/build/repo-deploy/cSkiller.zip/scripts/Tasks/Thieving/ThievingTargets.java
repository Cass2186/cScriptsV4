package scripts.Tasks.Thieving;

public enum ThievingTargets {
    MAN,
    ARDY_KNIGHT,
    ELF;

}
