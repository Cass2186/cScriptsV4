package scripts.Tasks.Crafting.Armour;

public class Leather {
}
