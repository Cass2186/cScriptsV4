package scripts.Tasks.Hunter.HunterData;


public enum TrapTypes {
    NET_TRAP,
    BOX_TRAP,
    BIRD_TRAP
}