package scripts.Tasks.Slayer.SlayerConst;

public enum GearType {

    MELEE,
    MAGIC_MELEE,
    RANGED,
    MAGIC
}
