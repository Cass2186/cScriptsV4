package scripts.Tasks.Slayer.SlayerConst;

public enum PrayerType {

    NONE,
    MAGIC,
    MISSLES,
    MELEE;
}
