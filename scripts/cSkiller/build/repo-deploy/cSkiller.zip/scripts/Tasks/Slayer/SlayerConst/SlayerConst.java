package scripts.Tasks.Slayer.SlayerConst;

public class SlayerConst {

    public static int TASK_STREAK_VARBIT = 4069;
    public static int REMAINING_KILLS_GAMESETTING = 394;
    public static int SLAYER_POINTS_VARBIT = 4068;
    public static int CBALLS_LEFT_GAMESETTING = 3;

}
