package scripts.Tasks.Slayer.SlayerConst;

public enum Masters {
    TURAEL,
    VANNAKA,
    CHAELDAR,
    NIEVE
}
