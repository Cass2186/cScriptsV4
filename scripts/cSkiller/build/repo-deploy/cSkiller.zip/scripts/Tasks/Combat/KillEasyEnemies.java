package scripts.Tasks.Combat;

public class KillEasyEnemies {
}
