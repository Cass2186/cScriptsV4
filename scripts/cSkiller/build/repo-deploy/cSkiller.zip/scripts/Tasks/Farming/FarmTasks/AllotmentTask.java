package scripts.Tasks.Farming.FarmTasks;

public class AllotmentTask {
}
