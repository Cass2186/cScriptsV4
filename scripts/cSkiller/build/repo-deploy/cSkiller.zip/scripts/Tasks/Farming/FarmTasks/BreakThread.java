package scripts.Tasks.Farming.FarmTasks;

import org.tribot.api.General;
import scripts.Data.Vars;
import scripts.Tasks.Farming.Data.FarmTask;

public class BreakThread implements Runnable {





    @Override
    public void run() {


    }
}

