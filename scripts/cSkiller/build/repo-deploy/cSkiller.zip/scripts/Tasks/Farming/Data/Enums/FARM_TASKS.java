package scripts.Tasks.Farming.Data.Enums;

public enum FARM_TASKS {
    ALLOTMENT,
    HERBS_AND_FLOWER,
    TREE,
    FRUIT_TREE;
}
