package scripts.Tasks.BirdHouseRuns.Data;

import org.tribot.api2007.types.RSTile;

public class Areas {

    public static RSTile SPACE_ONE_TILE = new RSTile(3680, 3815, 0);
    public static RSTile SPACE_TWO_TILE = new RSTile(3677, 3881, 0);
    public static RSTile SPACE_THREE_TILE = new RSTile(3762, 3755, 0);
    public static RSTile SPACE_FOUR_TILE = new RSTile(3768, 3760, 0);
    public static RSTile WEST_MUSHROOM_TILE = new RSTile(3677, 3871, 0);

}
