package scripts.Tasks.Runecrafting.Guardians;

public enum CellType {
    Weak,
    Medium,
    Strong,
    Overcharged
}
