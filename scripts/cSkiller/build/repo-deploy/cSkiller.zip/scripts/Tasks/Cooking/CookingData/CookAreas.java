package scripts.Tasks.Cooking.CookingData;

public enum CookAreas {

    CATHERBY,
    AL_KHARID,
    ROGUES_DEN;


}
