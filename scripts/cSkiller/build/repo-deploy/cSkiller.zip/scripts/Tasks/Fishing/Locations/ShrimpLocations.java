package scripts.Tasks.Fishing.Locations;

public enum ShrimpLocations {
    LUMBRIDGE_SWAMP
}
