package scripts.Tasks.Fishing.Locations;

import org.tribot.api2007.types.RSArea;

public enum LobsterLocations{
    KARAMJA,
    ;


}
