package scripts.Tasks.Fishing.Locations;

public enum LobsterLocations {
    KARAMJA,

}
