package scripts.Tasks.Fishing.Locations;

public enum RodLocations {
    BARBARIAN_VILLAGE,
    AL_KHARID;
}
