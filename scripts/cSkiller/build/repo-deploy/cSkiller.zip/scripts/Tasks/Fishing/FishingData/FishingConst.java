package scripts.Tasks.Fishing.FishingData;

import org.tribot.api2007.types.RSTile;

public class FishingConst {

    public static int FISHING_NPC_ID = 1526;
    public static  int BARBARIAN_ROD = 11323;
    public static RSTile BARB_FISHING_TILE = new RSTile(2499, 3506, 0);

}
