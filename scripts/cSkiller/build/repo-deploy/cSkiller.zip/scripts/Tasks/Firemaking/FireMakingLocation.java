package scripts.Tasks.Firemaking;

public enum FireMakingLocation {
    GRAND_EXCHANGE,
    SEERS,
    ARDOUGNE
}
