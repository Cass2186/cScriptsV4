package scripts.Tasks.Agility.Tasks.Wilderness;

public class GoToWildernessCourse {
}
