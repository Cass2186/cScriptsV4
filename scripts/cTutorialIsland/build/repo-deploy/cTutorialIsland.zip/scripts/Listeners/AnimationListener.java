package scripts.Listeners;

public interface AnimationListener {
    void onAnimationChanged(int newAnimation);
}